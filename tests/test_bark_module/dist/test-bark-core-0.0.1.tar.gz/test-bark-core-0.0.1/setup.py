#!/usr/bin/env python


"""
Setup script for `bark_core`
"""


from setuptools import setup


setup()  # Config in setup.cfg